	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" >
		<!--Font Awesome -->
		<link rel="stylesheet" href="<?php echo e(asset('fontawesome-free/css/all.min.css')); ?>">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>RadzHomestay</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/linearicons.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/font-awesome.min.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/bootstrap.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/magnific-popup.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/nice-select.css')); ?>">							
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/animate.min.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/owl.carousel.css')); ?>">			
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/jquery-ui.css')); ?>">			
			<link rel="stylesheet" href="<?php echo e(asset('guest/css/main.css')); ?>">
			
		</head>
		<body>	
			
		<!-- #header -->
		<?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--- end header -->
		<?php echo $__env->yieldContent('content'); ?>
	</body>
	</html>
	<?php /**PATH C:\xampp\htdocs\IK_HomeLiving\resources\views/includes/master2.blade.php ENDPATH**/ ?>